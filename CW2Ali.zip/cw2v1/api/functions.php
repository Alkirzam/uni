<?php
require_once "open.php";

// Database connection
function connectDB() {
    global $db_host, $db_user, $db_pass, $db_name;
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}



function get_artist($conn, $artist_id) {
    $query = "SELECT * FROM artist WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $artist_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    return $result->fetch_assoc();
}

function get_all_artists($conn) {
    $query = "SELECT * FROM artist";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    $artists = [];
    while ($row = $result->fetch_assoc()) {
        $artists[] = $row;
    }
    return $artists;
}


//Update artist
function update_artist($conn, $artist_data) {
    $artist_id = $artist_data['artist_id'];
    $artist_name = $artist_data['artist_name'];
    $artist_bio = $artist_data['bio'];
    $artist_facebook = $artist_data['facebook'];
    $artist_twitter = $artist_data['twitter'];
    $artist_instagram = $artist_data['instagram'];
    
    
    // Handle the image upload
    if (isset($artist_data['image_url']) && $artist_data['image_url']['error'] == 0) {
        $max_file_size = 2 * 1024 * 1024;
        if ($artist_data["image_url"]["size"] > $max_file_size) {
            echo "Error: File size too large. Maximum file size is " . ($max_file_size / 1024) . " KB.";
            exit();
        }
        
        $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/CW2v1/image";
        $target_file = $target_dir . "/" . basename($artist_data["image_url"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (move_uploaded_file($artist_data["image_url"]["tmp_name"], $target_file)) {
            $image_url = "/CW2v1/image/" . basename($artist_data["image_url"]["name"]);
            echo "Image URL: " . $image_url;
        } else {
            echo "Error uploading image file.";
            exit();
        }
    } else {
        echo "No image file uploaded.";
        exit();
    }
    
    $stmt_update_artist = $conn->prepare("UPDATE artist SET artist_name=?, bio=?, 
                            facebook=?, twitter=?, instagram=?, image_url=? WHERE id=?");
    $stmt_update_artist->bind_param("ssssssi", $artist_name, $artist_bio, $artist_facebook,
        $artist_twitter, $artist_instagram, $image_url, $artist_id);
    
    if (!$stmt_update_artist->execute()) {
        echo "Error updating artist: " . $stmt_update_artist->error;
        $conn->rollback();
        exit();
    }
    
    //---Commit the changes and close the statement
    $conn->commit();
    $stmt_update_artist->close();
    
    
    
    //---Display a success message
    $success_message = "Artist updated successfully.";
    echo "<script type='text/javascript'>alert('$success_message');</script>";
    echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
    exit();
}




//---Add new event

function add_new_event(mysqli $conn, array $data): string|false {
    $category_description =  "{$data['event_name']}. {$data['category_description']}";
    
    $category_insert_query = "INSERT INTO category (type, description) VALUES (?, ?)";
    $category_insert_stmt = $conn->prepare($category_insert_query);
    
    if (!$category_insert_stmt) {
        echo "Prepare failed: ({$conn->errno}) {$conn->error}";
        return false;
    }
    
    $category_insert_stmt->bind_param("ss", $data['event_category_name'], $category_description);
    
    if (!$category_insert_stmt->execute()) {
        echo "Category execute failed: ({$category_insert_stmt->errno}) {$category_insert_stmt->error}";
        return false;
    }
    
    $event_category_id = $conn->insert_id;
    
    $query = "INSERT INTO event (date, start_time, end_time, artist_id, event_category, 
                max_capacity, entrance_fee) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        echo "Prepare failed: ({$conn->errno}) {$conn->error}";
        return false;
    }
    
    $stmt->bind_param("sssiidd", $data['event_date'], $data['event_start_time'], 
                      $data['event_end_time'], $data['artist_id'], $event_category_id,
                        $data['event_capacity'], $data['event_entrance_fee']);
    
    if (!$stmt->execute()) {
        echo "Event execute failed: ({$stmt->errno}) {$stmt->error}";
        return false;
    }
    
    return "New event created successfully.";
}





function get_artis(PDO $conn): array {
    $artists = [];
    $query = "SELECT id, artist_name, image_url FROM artist ORDER BY RAND() LIMIT 3";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($result as $row) {
        $artists[] = $row;
    }
    
    return $artists;
}




function get_artists($conn) {
    $artists = [];
    $query = "SELECT id, artist_name FROM artist";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    while ($row = $result->fetch_assoc()) {
        $artists[] = $row;
    }
    return $artists;
}




function get_events(mysqli $conn): mysqli_result|false {
    $query = "SELECT e.date, e.start_time, e.end_time, c.description, e.artist_id, e.max_capacity,
                 e.entrance_fee FROM event e INNER JOIN category c ON e.event_category = c.id;";
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        echo "Prepare failed: ({$conn->errno}) {$conn->error}";
        return false;
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    
    return $result;
}




//Update Events
function update_event($conn, $old_event_date, $old_event_start_time, $new_event_date = null, 
                     $new_event_start_time = null, $event_end_time = null, $artist_id = null, $event_name = null, 
                         $event_capacity = null, $event_entrance_fee = null, $category_description = null) {
    
    $query = "UPDATE event SET ";
    $params = [];
    $param_values = [];
    
    if ($new_event_date) {
        
        $query .= "date = ?, "; $params[] = "s"; $param_values[] = &$new_event_date;
    }
    
    if ($new_event_start_time) {
        
        $query .= "start_time = ?, "; $params[] = "s"; $param_values[] = &$new_event_start_time;
    }
    
    if ($event_end_time) {
        
        $query .= "end_time = ?, "; $params[] = "s"; $param_values[] = &$event_end_time;
    }
    
    if ($artist_id) {
        
        $query .= "artist_id = ?, ";  $params[] = "i"; $param_values[] = &$artist_id;
    }
    
    if ($event_capacity) {
        
        $query .= "max_capacity = ?, "; $params[] = "i"; $param_values[] = &$event_capacity;
    }
    
    if ($event_entrance_fee) {
        
        $query .= "entrance_fee = ?, "; $params[] = "s"; $param_values[] = &$event_entrance_fee;
    }
    
    if ($category_description) {
        $event_name =  $event_name;
        $category_insert_query = "INSERT INTO category (type, description) VALUES (?, ?)";
        $category_insert_stmt = $conn->prepare($category_insert_query);
        $category_insert_stmt->bind_param("ss", $category_description, $event_name);
        $category_insert_stmt->execute();
        $event_category_id = $category_insert_stmt->insert_id;
        
        $query .= "event_category = ?, ";
        $params[] = "i";
        $param_values[] = &$event_category_id;
    }
    
    
    //Remove the comma and space from the query
    $query = rtrim($query, ', ');
    
    $query .= " WHERE date = ? AND start_time = ?";
    
    $params[] = "ss";
    $param_values[] = &$old_event_date;
    $param_values[] = &$old_event_start_time;
    
    $stmt = $conn->prepare($query);
    $types = implode('', $params);
    $stmt->bind_param($types, ...$param_values);
    
    $stmt->execute();
    
    if ($stmt->error) {
        die('Error executing query: ' . $stmt->error);
    }
    
    $stmt->close();
    $conn->commit();
}




//Display the Upcoming and past Events for the index, upcoming , past events page and display artist page with the artist events
function displayEvents(string $query, string $db_host, string $db_name, string $db_user,
    string $db_pass, string $section_title, string $artist_name, string $order_class, ?int $artist_id = null): void {
        $conn = new PDO(
            dsn: "mysql:host=$db_host;dbname=$db_name",
            username: $db_user,
            password: $db_pass
            );
        $stmt = $conn->prepare($query);
        
        if ($artist_id !== null) {
            $stmt->bindParam(':artist_id', $artist_id, PDO::PARAM_INT);
        }
        
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        

        
        // Loop for events
        foreach ($result as $row) {
            $artist_name = $row['artist_name'];
            $start = $row['start_time'];
            $end = $row['end_time'];
            $event_name  = $row['description'];
            $entrance_fee = $row['entrance_fee'];
            $max_capacity = $row['max_capacity'];
            $facebook = $row['facebook'];
            $twitter = $row['twitter'];
            $instagram = $row['instagram'];
            $image_url = $row['image_url'];
            $BIO = $row['bio'];
            $artist_id = $row['artist_id'];
            $date = $row['date'];
            $category = $row['category'];
            $uk_date = date('d/m/Y', strtotime($date));
            
            //Display the events
            echo '<div class="container">';
            echo '<hr class="featurette-divider">';
            echo '<div class="row featurette">';
            echo '<div class="col-md-7">';
            echo '<div class="featurette-heading"><h1>' . $section_title . '<br>' .' '  . $artist_name .'</h1><span class="text-muted"></span></div>';
            echo '<div class="lead"></div>';
            echo '</div>';
            echo '</div>';
            
            echo '<div class="row featurette">';
            echo '<div class="col-md-7 ' . $order_class . '">';
            echo '<h2 class="card-title"><strong>' . $event_name . '</strong></h2>';
            echo '<br>';
            echo '<a href="artist_events.php?artist_id=' . $row['artist_id'] . '&date=' . $row['date'] . '&start_time=' . $row['start_time'] . '">';
            echo '<img src="' . $row['image_url'] . '" alt="' . $row['artist_name'] . '" class="featurette-image img-fluid mx-auto" style="width: 50%; max-width: 250px;">';
            echo '</a>';
            echo '<div class="my-3">';
            echo '<h3>Social media </h3>';
            echo '<a href="' . $facebook . '" class="btn btn-primary btn-fit facebook mr-3"><i class="fa fa-facebook"></i></a>';
            echo '<a href="' . $twitter . '" class="btn btn-primary btn-fit twitter mr-3"><i class="fa fa-twitter"></i></a>';
            echo '<a href="' . $instagram . '" class="btn btn-primary btn-fit instagram mr-3"><i class="fa fa-instagram"></i></a>';
            echo '</div>';
            echo '</div>';
            echo '<div class="col-md-5 my-3">';
            echo '<br><br><br>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>Artist Name:</strong> ' . $artist_name . '</p>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>Category:</strong> ' . $category . '</p>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>Entrance Fee:</strong> ' . $entrance_fee . '</p>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>Max Capacity:</strong> ' . $max_capacity . '</p>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>Event Date:</strong> ' . $uk_date . '</p>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>Start Time:</strong> ' . $start . ' - <strong>End Time:</strong> ' . $end . '</p>';
            echo '<p class="card-text" style="word-wrap: break-word;"><strong>BIO:</strong>' . $BIO . '</p>';
            echo '</div>';
            echo '</div>';
            echo '<hr class="featurette-divider">';
            echo '</div>';
            
        }
        
        $conn = null;
}




?>


