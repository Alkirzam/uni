<?php
$db_host = 'localhost';
$db_name = 'cw1';
$db_user = 'root';
$db_pass = '';
