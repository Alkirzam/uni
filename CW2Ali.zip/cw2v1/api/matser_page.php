<!DOCTYPE html>
<html>
<head>
    <title><?php echo $pageTitle; ?></title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/cw2v1/css/style.css">
</head>
<body style="background-color: black;">


    <header>
    
    
    
    <nav class="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Main navigation" style="background-color: black;">
    
    <div class="container">
      <a class="navbar-brand" href="/cw2v1/index.php">
        <div class="row align-items-center">
          <div class="logo">
            <img src="\CW2v1\image\logo.png" alt="Logo">
            <h1 class="logo-text" style="color: white;">Ali</h1>
          </div>
        </div>
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/cw2v1/index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/cw2v1/upcoming_events.php">Upcoming Events</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/cw2v1/past_event.php">Past Events</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/cw2v1/admin_form.php">Admin </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/cw2v1/index.php.#contact">Contact</a>
          </li>
        </ul>
        
      </div>
    </div>
  </nav>  
  
  
  
 </header>





    <main>
    
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item p-2"><a href="/cw2v1/index.php">Home</a></li>
                <li class="breadcrumb-item active p-2" aria-current="page"><?php echo $pageTitle; ?></li>
            </ol>
        </nav>

        <?php echo $content; ?>
        
    </main>








    <footer id="footer" class="bg-dark py-3">
	<div class="container">
    <div class="row">
      <div class="col-md-6">
        <p>&copy; 2023 Ali. All rights reserved.</p>
      </div>
      <div class="col-md-6">
        <ul class="list-inline text-md-end">
          <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
          <li class="list-inline-item"><a href="#">Terms of Use</a></li>
        </ul>
      </div>
    </div>
  </div>    
  </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
 <script src="/cw2v1/js/script.js"></script> 
</body>
</html>
