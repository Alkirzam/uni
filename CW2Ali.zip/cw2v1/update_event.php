<?php
declare(strict_types=1);

include "./api/open.php";
include "./api/functions.php"; // Include the functions.php file


        $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

            //----Get the list of artists--
                $artists = get_artists($conn);

           //--Get the list of events--
                $result = get_events($conn);


        if (isset($_POST['update_event'])) {
                [$old_event_date, $old_event_start_time] = explode('|', $_POST['event']);
    
                $update_params = [
                    'new_event_date' => $_POST['new_date'] ?? null,
        
                    'new_event_start_time' => $_POST['new_start_time'] ?? null,
        
                    'event_end_time' => $_POST['end_time'] ?? null,
        
                    'artist_id' => $_POST['artist_id'] ?? null,
        
                    'event_name' => $_POST['description'] ?? null,
        
                    'event_capacity' => $_POST['capacity'] ?? null,
        
                    'event_entrance_fee' => $_POST['entrance_fee'] ?? null,
        
                    'category_description' => $_POST['type'] ?? null
    
                    
                ];
    
                update_event($conn, $old_event_date, $old_event_start_time, ...array_values($update_params));
    
    
    //--Display success message--
    
                $success_message = "Event updated successfully.";
    
                echo "<script type='text/javascript'>alert('$success_message');</script>";
    
                mysqli_close($conn);
    
                echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
    
                exit();

        }


        
        if ($conn->connect_error) {
    
            die("Connection failed: " . $conn->connect_error);

        }

 
        $query = "SELECT e.date, e.start_time, e.end_time, c.description, e.artist_id, e.max_capacity, e.entrance_fee FROM event e INNER JOIN category c ON e.event_category = c.id;";

        $result = $conn->query($query);

    
        if ($result->num_rows > 0) :

        ?>


		<div class="container my-5" id="update-event-form" style="display:none;">
    
    		<div class="row justify-content-center">
        		<div class="col-lg-8">
            		<div class="card shadow-lg p-5 mb-5">
				<h3 class="text-center mb-4" style="color: black;">Update Event</h3>

            <form action="update_event.php" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="event_id" class="form-label" style="color: black;">Select event to update:</label>
                    <select name="event" id="event" class="form-select" onchange="fillEventDetails()" required>
                        <option value="">-- Choose an event --</option>

                        <?php                            
                        while ($row = $result->fetch_assoc()) {
                            //--Convert the date to UK format--
                            $date = DateTime::createFromFormat('Y-m-d', $row['date']);
                            $ukDate = $date->format('d/m/Y');
                            
                            echo '<option value="' . $row['date'] . '|' . $row['start_time'] . '" data-date="' . $ukDate . '" data-start_time="' . $row['start_time'] . '" data-end_time="' . $row['end_time'] . '" data-description="' . $row['description'] . '" data-artist_id="' . $row['artist_id'] . '" data-max_capacity="' . $row['max_capacity'] . '" data-entrance_fee="' . $row['entrance_fee'] . '">' . $row['description'] . ' (' . $ukDate . ' ' . $row['start_time'] . ')</option>';
                        }
                        
                        ?>
	                    </select>
    	            </div>

	                <div id="update-event-details" style="display: block;">
	                    <div class="mb-3">
    	                    <label for="new_date" class="form-label" style="color: black;">New Event Date:</label>
        	                <input type="date" name="new_date" id="new_date" class="form-control">
            	        </div>

                    <div class="mb-3">
	                        <label for="new_start_time" class="form-label" style="color: black;">New Start Time:</label>
    	                    <input type="time" name="new_start_time" id="new_start_time" class="form-control">
                    </div>

                    <div class="mb-3">
	                        <label for="end_time" class="form-label" style="color: black;">End Time:</label>
    	                    <input type="time" name="end_time" id="end_time" class="form-control">
                    </div>
                    
                    <div class="mb-3">
        	                <label for="event_name" class="form-label" style="color: black;">Event Name:</label>
            	            <input type="text" name="description" id="description" class="form-control">
                    </div>

                    <div class="mb-3">
	                        <label for="type" class="form-label" style="color: black;">Category:</label>
    		                    <select name="type" id="type" class="form-select">
            	                <option value="">-- Choosea category --</option>
                	            <option value="poetry">Poetry</option>
                                <option value="music">Music</option>
                                <option value="comedy">Comedy</option>
								</select>
					</div>
                    <div class="mb-3">
                    	    <label for="capacity" class="form-label" style="color: black;">Capacity:</label>
                        	<input type="number" name="capacity" id="capacity" class="form-control">
                    </div>

                    <div class="mb-3">
	                        <label for="entrance_fee" class="form-label" style="color: black;">Entrance Fee:</label>
    	                    <input type="number" name="entrance_fee" id="entrance_fee" class="form-control">
                    </div>

                    <div class="mb-3">
	                        <label for="artist_id" class="form-label" style="color: black;">Artist:</label>
    	                    <select name="artist_id" id="artist_id" class="form-select">
                            <option value="">-- Choose an artist --</option>
                            <?php foreach ($artists as $artist) : ?>
                                <option value="<?php echo $artist['id']; ?>"><?php echo $artist['artist_name']; ?></option>
                            <?php endforeach; ?>
        	                </select>
                    </div>

		                    <input type="submit" name="update_event" value="Update Event" class="btn btn-primary my-3">
        		            <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
                	</div>
            		</form>
        		</div>
    		</div>
		</div>
	</div>
	
	<?php else : ?>
	<div class="card shadow-lg p-5 ">
    		<p class="text-center text-dark">No events found. Please add some events before updating.</p>
    	<div class="d-grid gap-2">
        	<a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
    	</div>
	</div>
	
	<?php endif; ?>