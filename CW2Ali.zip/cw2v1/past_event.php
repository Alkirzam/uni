<?php
require_once "./api/functions.php";

$pageTitle = "Past Events";
ob_start();
$conn = connectDB();

?>

<div class="container">
  <hr class="featurette-divider">
  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">Past Events <span class="text-muted">Check out what happened.</span></h2>
      <p class="lead">Here's a list of past events.</p>
    </div>
  </div>
  <form method="GET" class="mb-3">
    <div class="input-group">
      <label for="sort_by" class="input-group-text bg-dark text-white border-0">Sort by:</label>
      <select name="sort_by" id="sort_by" class="form-select bg-dark text-white border-0">
        <option value="a.artist_name">All</option>
        <option value="e.date">Date</option>
        <option value="e.start_time">Time</option>
      </select>
      <label for="category" class="input-group-text bg-dark text-white border-0">Category:</label>
      <select name="category" id="category" class="form-select bg-dark text-white border-0">
        <option value="">All</option>
        <option value="music">Music</option>
        <option value="poetry">Poetry</option>
        <option value="comedy">Comedy</option>
      </select>

      <label for="artist_name" class="input-group-text bg-dark text-white border-0">Artist:</label>
      <select name="artist_name" id="artist_name" class="form-select bg-dark text-white border-0">
        <option value="">All</option>
        <?php
          $query = "SELECT DISTINCT artist_name FROM artist ORDER BY artist_name";
          $stmt = $conn->prepare($query);
          $stmt->execute();
          $result = $stmt->get_result();
          while ($row = $result->fetch_assoc()) {
            $selected = $artist_name === $row['artist_name'] ? 'selected' : '';
            echo '<option value="' . $row['artist_name'] . '" ' . $selected . '>' . $row['artist_name'] . '</option>';
          }
          mysqli_free_result($result);
        ?>
      </select>

      <div class="d-grid gap-2 p-1">
        <input type="submit" value="Sort" class="btn btn-outline-light">
      </div>
    </div>
  </form>
</div>

<?php

  
     $sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'e.date';
     $category = isset($_GET['category']) ? $_GET['category'] : '';
     $artist_name = isset($_GET['artist_name']) ? $_GET['artist_name'] : '';


        $query = "SELECT a.id as artist_id, a.artist_name, a.bio, a.facebook, a.instagram,
                a.twitter, a.image_url, e.date, e.start_time, e.end_time, c.type AS category, c.description,
                e.entrance_fee, e.max_capacity FROM event e INNER JOIN artist a ON e.artist_id = a.id
                INNER JOIN category c ON e.event_category = c.id    WHERE e.date < CURDATE()";

        if (!empty($category)) {
    
            $query .= " AND c.type = '$category'";

        }

        if (!empty($artist_name)) {
    
 
            $query .= " AND a.artist_name = '$artist_name'";

        }

    
            $query .= " ORDER BY $sort_by DESC";


            displayEvents($query, $db_host, $db_name, $db_user, $db_pass, "Past Events", "Past", "order-md-2");


            $content = ob_get_clean();
            
            
include "./api/matser_page.php";
?>
    
