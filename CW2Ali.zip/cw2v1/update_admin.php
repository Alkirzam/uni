




<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card shadow-lg p-5">
        <form method="POST" action="./inc/update.php" id="update-user-info-form">
          <h2 class="mb-4"style="color: black;">Update User Information</h2>
          <div class="mb-3">
              <label for="new_username" class="form-label"style="color: black;">New Username:</label>
              <input type="text" class="form-control" name="new_username" id="new_username" required>
          </div>
          <div class="mb-3">
              <label for="new_password" class="form-label"style="color: black;">New Password:</label>
              <input type="password" class="form-control" name="new_password" id="new_password" required>
          </div>
                                       <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
          
          <button type="submit" class="btn btn-primary">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>
