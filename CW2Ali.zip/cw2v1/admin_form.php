<?php
$pageTitle = "Admin Setting page";
session_start();

$current_time = time();
$last_activity = $_SESSION['last_activity'] ?? 0;
if ($current_time - $last_activity > 1300) { 
    session_unset();
    session_destroy();
    $session_expired = true; 
    header("Location: loginform.php");
    exit();
}

if (isset($_SESSION['username'])) {
    echo '<div class="d-flex justify-content-between align-items-center  py-3">';
    echo '<div class="mx-3">Welcome back, ' . $_SESSION['username'] . ' to the Settings Page!</div>';
    echo '<form action="logOut.php" method="post">';
    echo '<button type="submit" class="btn btn-light mx-3">Logout</button>';
    echo '</form>';
    echo '</div>';
} else {
    header("Location: loginform.php");
    exit();
}

if (isset($session_expired) && $session_expired) {
    echo '<div class="alert alert-danger" role="alert">';
    echo 'Your session has expired. Please log in again.';
    echo '</div>';
}
?>



<div class="container" id="admin-settings-container">
<div class="container ">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card shadow-lg p-5 my-5">
        <div class="card-header my-3">
          <h1 class="card-title"style="color: black;">Admin Setting ...</h1>
        </div>
        
        
        <button id="show-add-artist-form" class="btn btn-dark mb-3">Add Artist</button>
        <button id="show-update-artist-form" class="btn btn-dark mb-3">Update Artist</button>
        <button id="show-delete-artist-form" class="btn btn-danger mb-3">Delete Artist</button>
        <button id="show-add-event-form" class="btn btn-dark mb-3" >Add Event</button>
        <button id="show-update-event-form" class="btn btn-dark mb-3">Update Event</button>
        <button id="show-delete-event-form" class="btn btn-danger mb-3">Delete Event</button>
        <button id="show-add-event-to-artist-form" class="btn btn-dark mb-3">Assign Event to Artist</button>
        <button id="show-update-user-info-form" class="btn btn-info mb-3">Update Admin Info</button>
                
        
        <form action="logOut.php" method="post">
          <button type="submit" class="btn btn-light">Logout</button>
        </form>
        
        
      </div>
    </div>
  </div>
</div>
</div>

<div id="form-container"></div>


<?php 
  $content = ob_get_clean();
  include_once "./api/matser_page.php";
?>


