<?php
include "./api/functions.php";
include "./api/open.php";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Get the list of artists
$artists = get_artists($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'event_name' => $_POST['description'],
        'event_date' => date("Y-m-d", strtotime($_POST['date'])),
        'event_start_time' => $_POST['start_time'],
        'event_end_time' => $_POST['end_time'],
        'event_category_name' => $_POST['type'],
        'event_capacity' => $_POST['capacity'],
        'event_entrance_fee' => $_POST['entrance_fee'],
        'artist_id' => $_POST['artist_id'],
    ];
    
    $result = add_new_event($conn, $data);
    
    if ($result !== false) {
        echo "<script type='text/javascript'>alert('$result');</script>";
        echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
    } else {
        echo "<script type='text/javascript'>alert('Error: Failed to create a new event.');</script>";
    }
}
?>

<div class="container my-5" id="add-event-form">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card shadow-lg p-5">
        <h3 class="text-center mb-5" style="color: black;">Add New Event</h3>

    <form method="post" enctype="multipart/form-data"action="add_new_event.php">
      <div class="form-group my-2">
        <label for="event_name"style="color: black;">Event Name</label>
<input type="text" id="description" name="description" class="form-control" placeholder="Enter event name" required>
      </div>
      
      <div class="form-group">
        <label for="event_date"style="color: black;">Event Date</label>
<input type="date" id="date" name="date" class="form-control" required>
      </div>

      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="start_time"style="color: black;">Event Start Time</label>
<input type="time" id="start_time" name="start_time" class="form-control" required>
        </div>
        
        <div class="form-group col-md-6">
          <label for="end_time"style="color: black;">Event End Time</label>
<input type="time" id="end_time" name="end_time" class="form-control" required>
        </div>
      </div>

 
<div class="form-row">
    <div class="form-group col-md-6">
        <label for="type" class="form-label" style="color: black;">Category:</label>
                        <select name="type" id="type" class="form-select">
                            <option value="">-- Choosea category --</option>
                            <option value="poetry">Poetry</option>
                                <option value="music">Music</option>
                                <option value="comedy">Comedy</option>

</select>
</div>
    
    <div class="form-group col-md-6">
        <label for="capacity"style="color: black;">Event Capacity</label>
        <input type="text" id="capacity" name="capacity" class="form-control" placeholder="Enter event capacity" required>
    </div>
</div>
<div class="form-group">
<label for="artist_id" style="color: black;">Artist</label>
<select class="form-control" id="artist_id" name="artist_id" required>
<option value="">Select an artist</option>
<?php foreach ($artists as $artist) : ?>
            <option value="<?php echo $artist['id']; ?>"><?php echo $artist['artist_name']; ?></option>
        <?php endforeach; ?>
    </select>
</div>

      <div class="form-group">
        <label for="entrance_fee"style="color: black;">Entrance Fee</label>
        <div class="input-group">
          <div class="input-group-prepend">
            <span class="input-group-text">£</span>
          </div>
<input type="text" id="entrance_fee" name="entrance_fee" class="form-control" aria-label="Amount (to the nearest dollar)" required>
          <div class="input-group-append">
            <span class="input-group-text">.00</span>
          </div>
        </div>
      </div>


<div class="d-grid gap-2">
    <button type="submit" class="btn btn-light">Submit</button>
    <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
</div>

</form>
</div>
</div>
</div>
</div>
