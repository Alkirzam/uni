



<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg p-5 mb-5">
                            <form action="./inc/add_new_artist.php" id="add-artist-form" method="post" enctype="multipart/form-data">
            
                <h3 class="text-center mb-4" style="color: black;">Add New Artist</h3>
                    <div class="mb-3">
                        <label for="artist_name" class="form-label" style="color: black;">Artist Name *</label>
                        <input type="text" id="artist_name" name="artist_name" class="form-control" placeholder="Name" aria-label="Name" aria-describedby="basic-addon1" required>
                    </div>
                    <div class="mb-3">
                        <label for="artist_bio" class="form-label" style="color: black;">Artist Bio *</label>
                        <input type="text" id="artist_bio" name="artist_bio" class="form-control" placeholder="Artist Bio" aria-label="Bio" aria-describedby="basic-addon1" required>
                    </div>
                    <div class="mb-3">
                        <label for="artist_facebook" class="form-label" style="color: black;">Facebook *</label>
                        <input type="text" id="artist_facebook" name="artist_facebook" class="form-control" aria-describedby="basic-addon3" required>
                    </div>
                    <div class="mb-3">
                        <label for="artist_twitter" class="form-label" style="color: black;">Twitter *</label>
                        <input type="text" id="artist_twitter" name="artist_twitter" class="form-control" aria-describedby="basic-addon3" required>
                    </div>
                    <div class="mb-3">
                        <label for="artist_instagram" class="form-label" style="color: black;">Instagram *</label>
                        <input type="text" id="artist_instagram" name="artist_instagram" class="form-control" aria-describedby="basic-addon3" required>
                    </div>
                    <div class="mb-3">
                        <label for="image_url" class="form-label" style="color: black;">Artist Image *</label>
                        <input type="file" id="image_url" name="image_url" class="form-control" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-light">Submit</button>
                        <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
                    </div>
                </form>
                <p class="text-center" style="color: black;">* Required fields</p>
            </div>
        </div>
    </div>
</div>

