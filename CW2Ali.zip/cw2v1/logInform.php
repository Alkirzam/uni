<?php
  $pageTitle = "Log In";
  ob_start();
?>
    


<body>
  <div class="container ">
    <div class="card mt-5 ">
      <div class="card-header ">
        <h1 class="card-title"style="color: black;">Admin Login</h1>
      </div>
      <div class="card-body">
        <?php if (isset($error_message)) { ?>
          <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php } ?>
        <form method="POST" action="login.php">
          <div class="mb-3">
            <label for="username" class="form-label"style="color: black;">Username:</label>
            <input type="text" class="form-control" name="username" id="username" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label"style="color: black;">Password:</label>
            <input type="password" class="form-control" name="password" id="password" required>
          </div>
          <button type="submit" class="btn btn-primary">Login</button>
        </form>
      </div>
    </div>
  </div>

</body>

<?php 
$content = ob_get_clean();
include "./api/matser_page.php";
?>

