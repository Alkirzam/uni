<?php
$pageTitle = "Home";
ob_start();
include "./api/open.php";
include "./api/functions.php";

?>



	<div class="container marketing">
  		<div class="row">
    		<?php
  
                    try {
  
                        $conn = new PDO(
                            dsn: "mysql:host=$db_host;dbname=$db_name",
                            username: $db_user,
                            password: $db_pass );
        
        
                        $artists = get_artis($conn);
        
        
                            foreach ($artists as $row) {
            
            echo '<div class="col-lg-2 mx-auto my-5 px-5">';
            echo '<a href="artist_events.php?artist_id=' . $row['id'] . '">';
            echo '<img src="' . $row['image_url'] . '" width="140" height="140" style="border-radius: 50%;"/>';
            echo '</a>';
            echo '<h5 class="col-lg-4  my-3 px-5"> '. $row['artist_name'] . '</h5>';
            echo '</div>';
        
                            }
        
       
                            $conn = null;
    
                    } catch (PDOException $e) {
        
                        header('Location: err500.php');
        
                        exit;
    
                    }
?>
  
  		</div>
	</div>




<?php 


        //---Upcoming event---
                $query = "SELECT a.id as artist_id, a.artist_name, a.bio, a.facebook, a.instagram,
                          a.twitter, a.image_url, e.date, e.start_time, e.end_time, c.type AS category, c.description,
                            e.entrance_fee, e.max_capacity FROM event e INNER JOIN artist a ON e.artist_id = a.id
                INNER JOIN category c ON e.event_category = c.id WHERE e.date >= CURDATE() ORDER BY e.date ASC LIMIT 1";
                
                
        displayEvents($query, $db_host, $db_name, $db_user, $db_pass, "Upcoming Events","Upcoming", "");

        //---Past event----
                $query = "SELECT a.id as artist_id, a.artist_name, a.bio, a.facebook, a.instagram,
                            a.twitter, a.image_url, e.date, e.start_time, e.end_time, c.type AS category, c.description,
                            e.entrance_fee, e.max_capacity FROM event e INNER JOIN artist a ON e.artist_id = a.id
                INNER JOIN category c ON e.event_category = c.id WHERE e.date < CURDATE() ORDER BY e.date DESC LIMIT 1";
                
                
        displayEvents($query, $db_host, $db_name, $db_user, $db_pass, "Past Events", "Past","order-md-2");

        ?>
        
        <section id="contact">
    <div class="container">
                           <h1 class="text-light"><strong>Here you can find Us.</strong></h1>
    
        <div class="row">
            <div class="col-lg-6">
                <div class="map-container">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d152201.03955547683!2d-3.05614172149132!3d53.4123000915186!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487adf8a647060b7%3A0x42dc046f3f176e01!2sLiverpool!5e0!3m2!1sen!2suk!4v1676408225424!5m2!1sen!2suk" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                </div>

            </div>
            <div class="col-lg-6">
                       <h1 class="text-light"><strong>Contact Us.</strong></h1>
            
            <form action="" method="POST" class="contact-form">
    <div class="form-group">
        <input type="text" name="name" id="" class="form-control" placeholder="Name">
        <i class="fa fa-user"></i>
    </div>
    <div class="form-group">
        <input type="email" name="email" id="" class="form-control" placeholder="Email">
        <i class="fa fa-envelope"></i>
    </div>
    <div class="form-group">
        <input type="text" name="subject" id="" class="form-control" placeholder="Subject">
        <i class="fa fa-book"></i>
    </div>
    <div class="form-group">
        <textarea type="text" name="message" id="" class="form-control" placeholder="Message"></textarea>
        <i class="fa fa-commenting"></i>
    </div>
    <button type="submit" class="btn btn-light">Send Message Now</button>
</form>


            </div>
        </div>
</div>
</section>
<hr class="featurette-divider">

        <?php 
        $content = ob_get_clean();
        
        include "./api/matser_page.php";
?>

