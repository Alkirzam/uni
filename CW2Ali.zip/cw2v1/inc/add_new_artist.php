<?php
include "open.php";

            $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

                    function display_success_message(string $message): void
            {
                    echo "<script type='text/javascript'>alert('$message');</script>";
                    echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
                
                    exit();
           
                    }

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
          
            }

            if ($_SERVER["REQUEST_METHOD"] === "POST") {
                        $artist_name = $_POST["artist_name"] ?? '';
                        $artist_bio = $_POST["artist_bio"] ?? '';
                        $artist_facebook = $_POST["artist_facebook"] ?? '';
                        $artist_twitter = $_POST["artist_twitter"] ?? '';
                        $artist_instagram = $_POST["artist_instagram"] ?? '';
    
            if (isset($_FILES["image_url"]) && $_FILES["image_url"]["error"] == 0) {
                    $max_file_size = 2 * 1024 * 1024;
        
            if ($_FILES["image_url"]["size"] > $max_file_size) {
                echo "Error: File size too large. Maximum file size is " . ($max_file_size / 1024) . " KB.";
            
            exit();
           
            }
        
        $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/CW2v1/image";
        $target_file = $target_dir . "/" . basename($_FILES["image_url"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (move_uploaded_file($_FILES["image_url"]["tmp_name"], $target_file)) {
            $image_url = "/CW2v1/image/" . basename($_FILES["image_url"]["name"]);
        
        } else {
            
            echo "Error uploading image file.";
            exit();
       
       
        }
        
         } else {
             
        echo "No image file uploaded.";
        exit();
   
         }
    
          $stmt_artist = $conn->prepare("INSERT INTO artist (artist_name, bio, facebook, twitter, instagram, image_url) VALUES (?, ?, ?, ?, ?, ?)");
          $stmt_artist->bind_param("ssssss", $artist_name, $artist_bio, $artist_facebook, $artist_twitter, $artist_instagram, $image_url);
            if (!$stmt_artist->execute()) {
        
                echo "Error inserting new artist: " . $conn->error;
        
                exit();

            }
                                   $success_message = "New artist created successfully with ID: " . $conn->insert_id;
    
                                   display_success_message($success_message);

            }

$conn->close();
?>


