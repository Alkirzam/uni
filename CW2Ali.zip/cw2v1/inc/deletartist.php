<?php

include "open.php";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$artists = [];
$sql = "SELECT id, artist_name FROM artist";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $artists[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $artist_id = $_POST["artist_id"];
    
    $conn->begin_transaction();
    
    $stmt_delete_artist = $conn->prepare("DELETE FROM artist WHERE id=?");
    $stmt_delete_artist->bind_param("i", $artist_id);
    if (!$stmt_delete_artist->execute()) {
        echo "Error deleting artist: " . $stmt_delete_artist->error;
        $conn->rollback();
        exit();
    }
    
    $conn->commit();
    
    mysqli_stmt_close($stmt_delete_artist);
    
    $success_message = "Artist deleted successfully with ID: " . $artist_id;
    echo "<script type='text/javascript'>alert('$success_message');</script>";
    echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
    exit();
    
    mysqli_close($conn);
}
?>
 <?php 
  if ($result->num_rows == 0) {
    echo "<div class='container my-5'id='delete-artist-form'style='display:none;'>";
    echo "<div class='row justify-content-center'>";
    echo "<div class='col-lg-8'>";
    echo "<div class='card shadow-lg p-5'>";
    echo "<p class='text-center text-dark'>No Artist found. Please add Artist before deleting.</p>";
    echo "</p>";
    echo "<div class='d-grid gap-2'>";
    echo "<a href='/cw2v1/admin_form.php' class='btn btn-light mb-3'>Back to Form</a>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    
} else {
?>

<div class="container my-3 " id="delete-artist-form">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card shadow-lg p-5 ">
        <h3 class="text-center mb-5" style="color: black;">Delete Artist</h3>
        <div class="p-5 bd-highlight justify-content-center bg-gray my-5">
          <form action="./inc/deletartist.php" method="post">
            <input type="hidden" name="action" value="delete_artist">
            <div class="input-group mb-3 my-2">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Artist</span>
              </div>
              <select class="form-control" id="delete_artist_id" name="artist_id">
                  <?php foreach                   ($artists as $artist) : ?>
                      <option value="<?php echo $artist['id']; ?>">
                          <?php echo $artist['artist_name']; ?>
                      </option>
                  <?php endforeach; ?>
              </select>
            </div>
            <div class="d-grid gap-2">
              <button type="submit" class="btn btn-danger">Delete</button>
              <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
} 

?>

                  