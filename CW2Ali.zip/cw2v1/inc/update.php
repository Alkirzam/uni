<?php
session_start();
include "open.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $new_username = $_POST["new_username"];
    $new_password = $_POST["new_password"];
    $admin_username = $_SESSION['username'];
    
    $stmt = $conn->prepare("UPDATE admin SET username = ?, password = ? WHERE username = ?");
    $stmt->bind_param("sss", $new_username, $new_password, $admin_username);
    
    if ($stmt->execute()) {
        $_SESSION['username'] = $new_username;
        $success_message = "User information updated successfully!";
        echo "<script type='text/javascript'>alert('$success_message');</script>";
        echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $stmt->close();
    mysqli_close($conn);
}
?>
