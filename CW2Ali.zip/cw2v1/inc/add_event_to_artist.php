<?php
declare(strict_types=1);

include "open.php";

                $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $event_id = $_POST["event_id"];
        $artist_id = $_POST["artist_id"];
    
        [$event_date, $event_start_time] = explode('|', $event_id);
    
        $sql = "UPDATE event SET artist_id=? WHERE date=? AND start_time=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $artist_id, $event_date, $event_start_time);
    
    if ($stmt->execute()) {
        $success_message = "Artist assigned successfully to the event.";
        echo "<script type='text/javascript'>alert('$success_message');</script>";
        echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
        } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
            
        }
    
        $stmt->close();
        mysqli_close($conn);
    }

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

?>

<!-- -- Assign form Event to Artist   -->
<body>

  <div class="container "id="add-event-to-artist-form" style="display">
    <div class="card mt-5 ">
      <div class="card-header ">
        <h1 class="card-title"style="color: black;">Assign Artist to Event</h1>     
        <form action="./inc/add_event_to_artist.php" method="post" class="mt-3">
            <div class="mb-3">
                <label for="event_id" class="form-label">Event</label>
                <select name="event_id" id="event_id" class="form-select" required>
                    <option value="">-- Select Event --</option>
                    <?php
                    $event_query = "SELECT e.date, e.start_time, c.description FROM event e INNER JOIN category c ON e.event_category = c.id ORDER BY e.date, e.start_time ASC";
                    $event_result = $conn->query($event_query);

                    while ($event_row = $event_result->fetch_assoc()) {
                        echo '<option value="' . $event_row['date'] . '|' . $event_row['start_time'] . '">' . $event_row['description'] . ' (' . $event_row['date'] . ' ' . $event_row['start_time'] . ')</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="artist_id" class="form-label">Artist</label>
                <select name="artist_id" id="artist_id" class="form-select" required>
                    <option value="">-- Select Artist --</option>
                    <?php
                    $artist_query = "SELECT id, artist_name FROM artist ORDER BY artist_name ASC";
                    $artist_result = $conn->query($artist_query);

                    while ($artist_row = $artist_result->fetch_assoc()) {
                        echo '<option value="' . $artist_row['id'] . '">' . $artist_row['artist_name'] . '</option>';
                    }

                    mysqli_close($conn);
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Assign Event </button>
              <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
            
        </form>
    </div>
    </div>
  </div>

    