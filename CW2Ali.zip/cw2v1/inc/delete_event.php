<?php
include "open.php";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$events = [];
$sql = "SELECT e.date, e.start_time, a.artist_name, e.artist_id, c.description AS event_category, c.id as category_id FROM event e LEFT JOIN artist a ON e.artist_id = a.id LEFT JOIN category c ON e.event_category = c.id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    [$event_date, $event_start_time, $category_id] = explode('|', $_POST["event_id"]);
    
    // Delete the event from the event table
    $stmt_delete_event = $conn->prepare("DELETE FROM event WHERE date=? AND start_time=?");
    $stmt_delete_event->bind_param("ss", $event_date, $event_start_time);
    
    // Delete the category from the category table
    $stmt_delete_category = $conn->prepare("DELETE FROM category WHERE id=?");
    $stmt_delete_category->bind_param("i", $category_id);
    
    // Execute the queries
    if (!$stmt_delete_event->execute()) {
        echo "Error deleting event: " . $stmt_delete_event->error;
        exit();
    }
    
    if (!$stmt_delete_category->execute()) {
        echo "Error deleting category: " . $stmt_delete_category->error;
        exit();
    }
    
    $stmt_delete_event->close();
    $stmt_delete_category->close();
    $conn->close();
    
    
    $success_message = "Event deleted successfully with ID: " . $category_id;
    echo "<script type='text/javascript'>alert('$success_message');</script>";
    echo "<script type='text/javascript'>window.location.href = '/cw2v1/admin_form.php';</script>";
    exit();
}





if ($result->num_rows == 0) {
    echo "<div class='container my-5'id='delete-event-form'style='display;'>";
    echo "<div class='row justify-content-center'>";
    echo "<div class='col-lg-8'>";
    echo "<div class='card shadow-lg p-5'>";
    echo "<p class='text-center text-dark'>No events found. Please add an event before deleting.";
    echo "</p>";
    echo "<div class='d-grid gap-2'>";
    echo "<a href='/cw2v1/admin_form.php' class='btn btn-light mb-3'>Back to Form</a>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
} else {
    ?>


<div class="container my-5" id="delete-event-form" style="display">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card shadow-lg p-5">
        <h3 class="text-center mb-5" style="color: black;">Delete Event</h3>
        <div class="p-5 bd-highlight justify-content-center bg-gray my-5">
          <form action="./inc/delete_event.php" method="post">
            <div class="input-group mb-3 my-2">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Select Event To Delete</span>
              </div>
              <select class="form-control" id="delete_event_id" name="event_id">
                <?php foreach ($events as $event) : ?>
                  <option value="<?php echo $event['date'] . '|' . $event['start_time'] . '|' . $event['category_id']; ?>">
<?php echo $event['event_category'] .')-( Date: ' . date('d/m/Y', strtotime($event['date'])) . ' )-( Artist: ' . $event['artist_name']  . ' )-( Start: ' . $event['start_time'].')'; ?>
</option>

                <?php endforeach; ?>
              </select>
            </div>
            <div class="d-grid gap-2">
              <button type="submit" class="btn btn-danger">Delete</button>
              <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
} 
?>
