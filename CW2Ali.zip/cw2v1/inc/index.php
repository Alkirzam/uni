
<?php
  $pageTitle = "Home";
  ob_start();
  include "./inc/open.php";
  
?>

<div class="container marketing">
  <!-- Three columns of text below the carousel -->
  <div class="row">
    <?php
    $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    
    $stmt = $conn->prepare('SELECT artist.artist_name, artist.facebook, artist.instagram, artist.twitter, 
                           artist.image_url, event.artist_id, event.date, event.start_time
                           FROM event RIGHT JOIN artist ON event.artist_id = artist.id ORDER BY RAND() LIMIT 3');
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($data as $row) {
        echo '<div class="col-lg-4 mx-auto my-5 px-5">';
        echo '<a href="./inc/artist_events.php?artist_id=' . $row['artist_id'] . '&date=' . $row['date'] . '&start_time=' . $row['start_time'] . '">';
        echo '<img src="' . $row['image_url'] . '" width="140" height="140" style="border-radius: 50%;"/>';
        echo '</a>';
        echo '<h5 class="col-lg-4  my-3 px-5"> '. $row['artist_name'] . '</h5>';
        echo '</div>';
    }
    

  
  
  $conn = null;
?>
  </div>
</div>



    

<div class="container">
  <hr class="featurette-divider">
  <div class="row featurette">
    <div class="col-md-7 ">
      <h2 class="featurette-heading">Up Coming Events <span class="text-muted">Check out what's on.</span></h2>
      <p class="lead">Here's a list of Up Coming events.</p>
    </div>
  </div>
  
  <?php
 

$conn = mysqli_connect($db_host, $db_user, $db_pass , $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$query = "SELECT a.id as artist_id, a.artist_name, a.bio, a.facebook, a.instagram, 
a.twitter, a.image_url, e.date, e.start_time, e.end_time, c.type AS category, c.description,
 e.entrance_fee, e.max_capacity FROM event e INNER JOIN artist a ON e.artist_id = a.id
INNER JOIN category c ON e.event_category = c.id WHERE e.date >= CURDATE() ORDER BY e.date ASC LIMIT 1";


$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();
$count = 0;

while ($row = $result->fetch_assoc()) {
    $artist_name = $row['artist_name'];
    $start = $row['start_time'];
    $end = $row['end_time'];
    $category = $row['category'];
    $entrance_fee = $row['entrance_fee'];
    $max_capacity = $row['max_capacity'];
    $facebook = $row['facebook'];
    $twitter = $row['twitter'];
    $instagram = $row['instagram'];
    $image_url = $row['image_url'];
    $BIO = $row['bio'];
    $artist_id = $row['artist_id'];
    $date = $row['date'];
    $event_name = $row['description'];
    $uk_date = date('d/m/Y', strtotime($date));

    if ($count % 2 == 0) {
      echo '<div class="row">';
    }
  ?>
    <hr class="featurette-divider">
    <div class="row featurette">
      <div class="col-md-7 order-md-2">
        <h2 class="card-title"><strong><?php echo $event_name; ?></strong></h2>
         <div class="card shadow-lg p-5 my-5">
        <a href="event.php?artist_id=<?php echo $artist_id; ?>&event_id=<?php echo $date; ?>" class="row featurette">
        <img src="<?php echo $image_url; ?>" class="img-fluid mx-auto" alt="Image description">
		</a>
             </div>
              <div class="my-3" > 
              <h3>Social media </h3>
              <a href="<?php echo $facebook; ?>" class="btn btn-primary btn-fit facebook"><i class="fa fa-facebook"></i></a>
  <a href="<?php echo $twitter; ?>" class="btn btn-primary btn-fit twitter"><i class="fa fa-twitter"></i></a>
  <a href="<?php echo $instagram; ?>" class="btn btn-primary btn-fit instagram"><i class="fa fa-instagram"></i></a>
              </div>
            </div>
    <div class="col-md-5 my-3 order-md-1">
        <br><br><br>
    
    <p class="card-text"style="word-wrap: break-word;"><strong>Artist Name:</strong> <?php echo $artist_name; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Category:</strong> <?php echo $category; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Entrance Fee:</strong> <?php echo $entrance_fee; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Max Capacity:</strong> <?php echo $max_capacity; ?></p>
        <p class="card-text"style="word-wrap: break-word;"> <strong>Event Date:</strong> <?php echo  $uk_date; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Start Time :</strong> <?php echo   $start; ?> - <strong>End Time :</strong> <?php echo   $end; ?></p>
        <p class="card-text " style="word-wrap: break-word;"><strong>BIO:</strong><?php echo $BIO; ?></p>
        
                
        
</div>
  </div>
  <hr class="featurette-divider">

<?php
    $count++;

    if ($count % 2 == 0) {
      echo '</div>';
    }
  }
  
  if ($count % 2 != 0) {
    echo '</div>';
  }

  mysqli_free_result($result);
  mysqli_close($conn);
?>

</div>



<div class="container">
  <hr class="featurette-divider">
  <div class="row featurette">
    <div class="col-md-7 order-by-2 ">
      <h2 class="featurette-heading"> Past Events <span class="text-muted">Check out what's on.</span></h2>
      <p class="lead">Here's a list of Up Coming events.</p>
    </div>
  </div>
  <?php
 

$conn = mysqli_connect($db_host, $db_user, $db_pass , $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$query = "SELECT a.id as artist_id, a.artist_name, a.bio, a.facebook, a.instagram, a.twitter,
 a.image_url, e.date, e.start_time, e.end_time, c.type AS category, c.description, e.entrance_fee, e.max_capacity
FROM event e INNER JOIN artist a ON e.artist_id = a.id INNER JOIN category c ON e.event_category = c.id
WHERE e.date < CURDATE() ORDER BY e.date ASC LIMIT 1";


$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();
$count = 0;

while ($row = $result->fetch_assoc()) {
    $artist_name = $row['artist_name'];
    $start = $row['start_time'];
    $end = $row['end_time'];
    $category = $row['category'];
    $entrance_fee = $row['entrance_fee'];
    $max_capacity = $row['max_capacity'];
    $facebook = $row['facebook'];
    $twitter = $row['twitter'];
    $instagram = $row['instagram'];
    $image_url = $row['image_url'];
    $BIO = $row['bio'];
    $artist_id = $row['artist_id'];
    $date = $row['date'];
    $event_name = $row['description'];
    $uk_date = date('d/m/Y', strtotime($date));

    if ($count % 2 == 0) {
      echo '<div class="row">';
    }
  ?>
    <hr class="featurette-divider">
    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="card-title"><strong><?php echo $event_name; ?></strong></h2>
         <div class="card shadow-lg p-5 my-5">
        <a href="event.php?artist_id=<?php echo $artist_id; ?>&event_id=<?php echo $date; ?>" class="row featurette">
        <img src="<?php echo $image_url; ?>" class="img-fluid mx-auto" alt="Image description">
		</a>
             </div>
              <div class="my-3" > 
              <h3>Social media </h3>
              <a href="<?php echo $facebook; ?>" class="btn btn-primary btn-fit facebook"><i class="fa fa-facebook"></i></a>
  <a href="<?php echo $twitter; ?>" class="btn btn-primary btn-fit twitter"><i class="fa fa-twitter"></i></a>
  <a href="<?php echo $instagram; ?>" class="btn btn-primary btn-fit instagram"><i class="fa fa-instagram"></i></a>
              </div>
            </div>
    <div class="col-md-5 my-3">
        <br><br><br>
    
    <p class="card-text"style="word-wrap: break-word;"><strong>Artist Name:</strong> <?php echo $artist_name; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Category:</strong> <?php echo $category; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Entrance Fee:</strong> <?php echo $entrance_fee; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Max Capacity:</strong> <?php echo $max_capacity; ?></p>
        <p class="card-text"style="word-wrap: break-word;"> <strong>Event Date:</strong> <?php echo  $uk_date; ?></p>
        <p class="card-text"style="word-wrap: break-word;"><strong>Start Time :</strong> <?php echo   $start; ?> - <strong>End Time :</strong> <?php echo   $end; ?></p>
        <p class="card-text " style="word-wrap: break-word;"><strong>BIO:</strong><?php echo $BIO; ?></p>
        
                
        
</div>
  </div>
  <hr class="featurette-divider">

<?php
    $count++;

    if ($count % 2 == 0) {
      echo '</div>';
    }
  }
  
  if ($count % 2 != 0) {
    echo '</div>';
  }

  mysqli_free_result($result);
  mysqli_close($conn);
?>

</div>

  <?php 
  $content = ob_get_clean();
  include "./inc/master_page.php";
  ?>


