<?php
session_start();
include "./inc/open.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
        
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        
        $admin_username = $_POST["username"];
        $admin_password = $_POST["password"];
        
        //--Check if the  admin credentials are correct--
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
        if (!$stmt) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }
        $stmt->bind_param("ss", $admin_username, $admin_password);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row) {
            $_SESSION['admin_username'] = $admin_username;
            $_SESSION['username'] = $row['username'];
            $_SESSION['last_activity'] = time();
            header("Location: /cw2v1/admin_form.php");
            exit();
        } else {
            $error_message = "Invalid username or password";
        }
        
        $stmt->close();
        mysqli_close($conn);
    } catch (Exception $e) {
        echo 'Error: ', $e->getMessage(), "\n";
        header('Location: err500.php');
        
    }
}

include("loginform.php");
?>
