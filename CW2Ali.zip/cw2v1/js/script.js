 
 
 // Function to hide the admin settings container
 
 function hideAdminSettingsContainer() {
	  $("#admin-settings-container").hide();
	}

// Function to be executed when the document is ready

	$(document).ready(function() {
	
	  // Click event handler for the 'show-add-event-form' button
	
	  $("#show-add-event-form").click(function() {
	      // Ajax request to load the 'add_new_event.php' form
	  
	    $.ajax({
	      url: "add_new_event.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#add-event-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-add-artist-form").click(function() {
	    $.ajax({
	      url: "add_artist_form.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#add-artist-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-update-artist-form").click(function() {
	    $.ajax({
	      url: "update_artist.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#update-artist-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-delete-artist-form").click(function() {
	    $.ajax({
	      url: "./inc/deletartist.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#delete-artist-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-update-event-form").click(function() {
	    $.ajax({
	      url: "update_event.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#update-event-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-delete-event-form").click(function() {
	    $.ajax({
	      url: "./inc/delete_event.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#delete-event-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-update-user-info-form").click(function() {
	    $.ajax({
	      url: "update_admin.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#update-user-info-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	  $("#show-add-event-to-artist-form").click(function() {
	    $.ajax({
	      url: "./inc/add_event_to_artist.php",
	      type: "GET",
	      success: function(response) {
	        $("#form-container").html(response);
	        $("#add-event-to-artist-form").show();
	      },
	      error: function() {
	        alert("Error loading form.");
	      }
	    });
	    hideAdminSettingsContainer();
	  });

	});

// Change event handler for the 'event' dropdown menu

	document.getElementById("event").addEventListener("change", function() {
	  // If a valid event is selected, show the update event details form and populate its fields
	
	    if (this.value !== "") {
	        document.getElementById("update-event-details").style.display = "block";
	        var selectedOption = this.options[this.selectedIndex];
	        document.getElementById("date").value = selectedOption.dataset.date;
	        document.getElementById("start_time").value = selectedOption.dataset.start_time;
	        document.getElementById("end_time").value = selectedOption.dataset.end_time;
	        document.getElementById("description").value = selectedOption.dataset.description;
	        document.getElementById("artist_id").value = selectedOption.dataset.artist_id;
	        document.getElementById("capacity").value = selectedOption.dataset.max_capacity;
	        document.getElementById("entrance_fee").value = selectedOption.dataset.entrance_fee;
	    } else {
	        // If no event is selected, hide the update event details form
	    
	        document.getElementById("update-event-details").style.display = "none";
	    }
	});
// Function to fill the event details fields with the selected event's information

	function fillEventDetails() {
	    const selectedEvent = document.getElementById("event");
	    const selectedOption = selectedEvent.options[selectedEvent.selectedIndex];

	    document.getElementById("new_date").value = selectedOption.getAttribute("data-date");
	    document.getElementById("new_start_time").value = selectedOption.getAttribute("data-start_time");
	    document.getElementById("end_time").value = selectedOption.getAttribute("data-end_time");
	    document.getElementById("description").value = selectedOption.getAttribute("data-description");
	    document.getElementById("artist_id").value = selectedOption.getAttribute("data-artist_id");
	    document.getElementById("capacity").value = selectedOption.getAttribute("data-max_capacity");
	    document.getElementById("entrance_fee").value = selectedOption.getAttribute("data-entrance_fee");
	}
