<?php
$pageTitle = "Update artist";
ob_start();
require_once "./api/open.php";
require_once "./api/functions.php";

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

            if ($conn->connect_error) {
    
                die("Connection failed: " . $conn->connect_error);

            }


            $artists = get_all_artists($conn);


    
            if (count($artists) == 0) {
 ?>
 
 
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-lg p-5">
                    <p class="text-center text-dark">No artist found. Please add some artists before updating.</p>
                    <div class="d-grid gap-2">
                        <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    
    
    } else {
   
        if (isset($_POST['update_artist']) && isset($_POST['artist_id']) && isset($_FILES['image_url'])) {
     
            $artist_data = $_POST;
       
            $artist_data['image_url'] = $_FILES['image_url'];

       
          if (!empty($artist_data['artist_name']) && !empty($artist_data['bio']) && !empty($artist_data['facebook']) && !empty($artist_data['twitter']) && !empty($artist_data['instagram']) && !empty($artist_data['image_url'])) {
          
              update_artist($conn, $artist_data);
       
          } else {
       
              echo "Please fill in all required fields.";
       
          }
   
        }
?>



<div class="container my-5" id="update-artist-form" style="display:none;">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg p-5">
                <form action="update_artist.php" method="post">
                    <input type="hidden" name="update_artist" value="1">
                    <div class="form-group">
                        <label for="artist_id" style="color: black;">Select Artist to Update</label>
                        <select class="form-control" name="artist_id" id="artist_id">
                            <?php
                            foreach ($artists as $artist) {
                            ?>
                                <option value="<?php echo $artist['id']; ?>"><?php echo $artist['artist_name']; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                        
                        <button type="submit" class="btn btn-light my-2" name="select_artist">Select</button>
                    </div>
                    <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php 
   
        if (session_status() == PHP_SESSION_NONE) {
       
            session_start();
   
        }

   
        if (isset($_POST['select_artist']) && isset($_POST['artist_id'])) {
       
            $artist_id = $_POST['artist_id'];
       
            $artist = get_artist($conn, $artist_id);
?>


<div class="container my-5">
    <div class="row justify-content-center">
       	<div class="col-lg-8">
         	<div class="card shadow-lg p-5">
             	   <form action="update_artist.php" method="post" enctype="multipart/form-data">
              	      <input type="hidden" name                 ="update_artist" value="1">
              		  <input type="hidden" name="artist_id" value="<?php echo $artist['id']; ?>">

              	  <div class="mb-3">
                	    <label for="artist_name" class="form-label" style="color: black;">Artist Name</label>
                  	    <input type="text" id="artist_name" name="artist_name" class="form-control" placeholder="Name" value="<?php echo $artist['artist_name']; ?>">
               	 </div>
               	 <div class="mb-3">
               		     <label for="bio" class="form-label" style="color: black;">Artist BIO</label>
              		      <input type="text" id="bio" name="bio" class="form-control" placeholder="Artist BIO" value="<?php echo $artist['bio']; ?>">
            	    </div>
            	    <div class="mb-3">
              		      <label for="facebook" class="form-label" style="color: black;">Artist Facebook</label>
             		       <input type="text" id="facebook" name="facebook" class="form-control" placeholder="Facebook" value="<?php echo $artist['facebook']; ?>">
          	      </div>
            	    <div class="mb-3">
            	        <label for="twitter" class="form-label" style="color: black;">Artist Twitter</label>
            	        <input type="text" id="twitter" name="twitter" class="form-control" placeholder="Twitter" value="<?php echo $artist['twitter']; ?>">
             	   </div>
             	   <div class="mb-3">
              	 	     <label for="instagram" class="form-label" style="color: black;">Artist Instagram</label>
             	   	    <input type="text" id="instagram" name="instagram" class="form-control" placeholder="Instagram" value="<?php echo $artist['instagram']; ?>">
           	     </div>
            	    <div class="mb-3">
              		      <label for="image_url" class="form-label" style="color: black;">Artist Image</label>
              		      <input type="file" id="image_url" name="image_url" class="form-control" required>
            	    </div>
            	    <div class="d-grid gap-2">                    
              		      <button type="submit" class="btn btn-light">Update</button>
             		       <a href="/cw2v1/admin_form.php" class="btn btn-light mb-3">Back to Form</a>
         	       </div>
                
        	    </form>
       	 	</div>
   		 </div>
	</div>
</div>


<?php 
$content = ob_get_clean();
include_once "./api/matser_page.php";
?>
<?php
}
}
?>