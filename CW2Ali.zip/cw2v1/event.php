<?php
$pageTitle = "Artist Events";
ob_start();
include "./inc/open.php";

?>


<?php
  $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
  

  if (isset($_GET['artist_id'])) {
      $artist_id = $_GET['artist_id'];
  } else {
  }
  
  $stmt = $conn->prepare('SELECT
  e.date, e.start_time, e.end_time, e.event_category, e.entrance_fee, e.max_capacity, a.id AS artist_id,c.type As category,
  a.instagram, a.twitter, a.facebook, a.image_url, a.artist_name,  a.bio, c.description AS event_name
FROM
  event AS e LEFT JOIN
  artist AS a ON e.artist_id = a.id LEFT JOIN
  category AS c ON e.event_category = c.id WHERE
  a.id = :artist_id AND e.date ORDER BY e.date ASC;');
  
  $stmt->bindParam(':artist_id', $artist_id);
  $stmt->execute();
  $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
  
  $stmt = $conn->prepare('SELECT image_url FROM artist WHERE id = :artist_id');
  $stmt->bindParam(':artist_id', $artist_id);
  $stmt->execute();
  $result = $stmt->fetch(PDO::FETCH_ASSOC);
  
  if ($result !== false) {
      $image_url = $result['image_url'];
  } else {
  }
  ?>
<hr class="featurette-divider">

<div class="container">
    <div class="row">
        <div class="col">
            <?php foreach($events as $row): ?>
                <div class="row featurette mb-7 order-md-2">
                    <div class="col-md-7 order-md-2">
                        <h2 class="featurette-heading"><?php echo $row['event_name']; ?> <span class="text-muted"><strong>Date:</strong> <?php echo date('d/m/Y', strtotime($row['date'])); ?></span></h2>
                        <p class="lead"><?php echo $row['start_time']; ?> - <?php echo $row['end_time']; ?></p>
                        <p class="lead"><?php echo $row['category']; ?></p>
                        <h4>Artist: <?php echo $row['artist_name']; ?></h4>
                        <p class="card-text " style="word-wrap: break-word;">Bio: <?php echo $row['bio']; ?></p>
                        <div class="my-3">
                            <h5>Social media</h5>
                             <a href="<?php echo $row['facebook']; ?>" class="btn btn-primary btn-fit facebook"><i class="fa fa-facebook"></i></a>
  <a href="<?php echo $row['twitter']; ?>" class="btn btn-primary btn-fit twitter"><i class="fa fa-twitter"></i></a>
  <a href="<?php echo $row['instagram']; ?>" class="btn btn-primary btn-fit instagram"><i class="fa fa-instagram"></i></a>

                        </div>
                    </div>
                    <div class="col-md-5 order-md-1">
                        <img src="<?php echo $row['image_url']; ?>" alt="<?php echo $row['artist_name']; ?>" class="featurette-image img-fluid mx-auto" style="width: 100%; max-width: 500px;">
</div>
</div>
<hr class="featurette-divider">
<?php endforeach; ?>
</div>
</div>
</div>



<?php
  $conn = null;
?>
<?php 
$content = ob_get_clean();
include "./api/matser_page.php";
?>
