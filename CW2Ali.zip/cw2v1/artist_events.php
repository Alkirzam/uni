<?php
$pageTitle = "Artist Event";
ob_start();
include "./api/open.php";
include "./api/functions.php";

$artist_id = $_GET['artist_id'];

//--Query for the artists events--//
$query = "SELECT a.id as artist_id, a.artist_name, a.bio, a.facebook, a.instagram,
a.twitter, a.image_url, e.date, e.start_time, e.end_time, c.type AS category, c.description,
e.entrance_fee, e.max_capacity FROM event e INNER JOIN artist a ON e.artist_id = a.id
INNER JOIN category c ON e.event_category = c.id WHERE a.id = :artist_id ORDER BY e.date DESC";

$conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
$stmt = $conn->prepare($query);
$stmt->bindParam(':artist_id', $artist_id, PDO::PARAM_INT);
$stmt->execute();
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($events)) {
    echo "<div class='alert alert-light'>There are no events for this artist.</div>";
} else {
    displayEvents($query, $db_host, $db_name, $db_user, $db_pass, " ", "", "", $artist_id);
}

$content = ob_get_clean();
include "./api/matser_page.php";
?>
