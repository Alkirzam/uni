<?php
$pageTitle = "500 Internal Server Error";
ob_start();
include "./api/open.php";
?>


    <div class="container my-5">
        <h1 class="text-danger">500 Internal Server Error</h1>
        <p>Sorry, the server encountered an error and was unable to complete your request.</p>
       <strong> To resolve this issue, please create the following tables: [artist], [category], [events], <br>
        and [admin], and then execute the insert data file to populate them with the necessary data.</strong>
        
    </div>
    
    
<?php 


$content = ob_get_clean();

include "./api/matser_page.php";
?>