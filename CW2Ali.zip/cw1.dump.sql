-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: cw1
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = latin1 */;
CREATE TABLE `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'Ali','123456');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = latin1 */;
CREATE TABLE `artist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `artist_name` varchar(255) DEFAULT NULL,
  `bio` text NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES (1,'Adele','British singer and songwriter...','https://www.facebook.com/adele','https://www.instagram.com/adele','https://twitter.com/adele','https://i2-prod.mirror.co.uk/incoming/article29632622.ece/ALTERNATES/s615/2_Adele-Performs-At-The-Genting-Arena.jpg'),(2,'Ed Sheeran','English singer, songwriter...','https://www.facebook.com/edsheeranmusic','https://www.instagram.com/teddysphotos','https://twitter.com/edsheeran','https://i2-prod.dailyrecord.co.uk/incoming/article29362571.ece/ALTERNATES/s615/0_Celebrity-Birthdays-Feb-12-Feb-18-New-York-United-States-10-Dec-2021.jpg'),(3,'Taylor Swift','American singer-songwriter...','https://www.facebook.com/taylorswift','https://www.instagram.com/taylorswift','https://twitter.com/taylorswift13','https://i2-prod.manchestereveningnews.co.uk/incoming/article26663275.ece/ALTERNATES/s1200c/0_Taylor-Swift-The-Eras-Tour-Concert-Arlington-Texas-United-States-31-Mar-2023.jpg'),(4,'Bruno Mars','American singer, songwriter...','https://www.facebook.com/brunomars','https://www.instagram.com/brunomars','https://twitter.com/brunomars','https://hips.hearstapps.com/hmg-prod/images/gettyimages-134315104.jpg'),(5,'Rihanna','Barbadian singer, actress...','https://www.facebook.com/rihanna','https://www.instagram.com/badgalriri','https://twitter.com/rihanna','https://pyxis.nymag.com/v1/imgs/6de/08c/1abb5c792286f8d7b9f800dd74308007f6-rihanna.rsquare.w700.jpg'),(6,'Kanye West','American rapper, producer...','https://www.facebook.com/kanyewest','https://www.instagram.com/kanyew.est','https://twitter.com/kanyewest','https://www.alo.co/__export/1669681688682/sites/alo/img/2022/11/28/kanye-west.webp_1296569939.webp'),(7,'Lady Gaga','American singer, songwriter...','https://www.facebook.com/ladygaga','https://www.instagram.com/ladygaga','https://twitter.com/ladygaga','https://media.vogue.co.uk/photos/61801c9e6dbe5c2e7756c102/2:3/w_2560%2Cc_limit/GettyImages-1346685071.jpg'),(8,'The Rolling Stones','Legendary rock band...','https://www.facebook.com/therollingstones','https://www.instagram.com/therollingstones/','https://twitter.com/RollingStones','https://pyxis.nymag.com/v1/imgs/3d6/6e9/e1be6c4345ee1ab837b291112ce65d9e4f-05-rolling-stones-feature-lede.2x.h600.w512.jpg');
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = latin1 */;
CREATE TABLE `category` (
  `id` smallint NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Music','Music events and concert'),(2,'Comedy','Comedy shows and performances'),(3,'Poetry','Poetry readings and events'),(4,'Music','Music events and concerts'),(5,'Comedy','Comedy shows and performances'),(6,'Poetry','Poetry readings and events'),(7,'Music','Music events and concerts'),(8,'Comedy','Comedy shows and performances'),(9,'Poetry','Poetry readings and events');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = latin1 */;
CREATE TABLE `event` (
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `artist_id` int DEFAULT NULL,
  `event_category` smallint DEFAULT NULL,
  `entrance_fee` double(10,0) NOT NULL,
  `max_capacity` smallint DEFAULT NULL,
  PRIMARY KEY (`date`,`start_time`),
  KEY `artist_id` (`artist_id`),
  KEY `event_category` (`event_category`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`id`) ON DELETE SET NULL,
  CONSTRAINT `event_ibfk_2` FOREIGN KEY (`event_category`) REFERENCES `category` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES ('2023-04-01','19:00:00','22:00:00',1,1,0,5000),('2023-04-02','20:00:00','23:00:00',2,2,0,4000),('2023-04-03','18:00:00','21:00:00',3,3,0,3000),('2023-04-04','19:30:00','22:30:00',4,4,0,4500),('2023-04-05','20:00:00','23:00:00',5,5,0,3500),('2023-04-06','21:00:00','00:00:00',6,6,0,4000),('2023-04-07','18:00:00','21:00:00',7,7,0,3000),('2023-05-11','19:30:00','22:30:00',1,1,0,5000),('2023-05-12','20:00:00','23:00:00',2,2,0,4000),('2023-05-13','18:00:00','21:00:00',3,1,0,3000),('2023-05-14','19:30:00','22:30:00',4,2,0,4500),('2023-05-15','20:00:00','23:00:00',5,8,0,3500),('2023-05-16','21:00:00','00:00:00',6,3,0,4000),('2023-05-17','18:00:00','21:00:00',7,4,0,3000),('2023-05-21','19:30:00','22:30:00',1,1,0,5000),('2023-05-22','20:00:00','23:00:00',2,2,0,4000),('2023-05-23','18:00:00','21:00:00',3,1,0,3000),('2023-05-24','19:30:00','22:30:00',4,2,0,4500),('2023-05-25','20:00:00','23:00:00',5,8,0,3500),('2023-05-26','21:00:00','00:00:00',6,3,0,4000),('2023-05-27','18:00:00','21:00:00',7,4,0,3000);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-17 14:44:44
